﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GroupGrindr
{
    /// <summary>
    /// Interaction logic for Create_Group_Page.xaml
    /// </summary>
    /// 
    public static class DisplayUsernamesData
    {
        public static int STARTING_COLUMN = 7;
        public static int TOTAL_USERNAMES;
        public static List<string> NAMES_IN;
        public static string Colour1;
        public static string Colour2;
    }
    public partial class Create_Group_Page : Page
    {
        public Create_Group_Page()
        {
            GlobalVariables.connectToDatabase();
            InitializeComponent();
            resetData();
            addSelfUser();
        }

        private void addSelfUser()
        {
            string username = GlobalVariables.currentPerson.Email;
            Group_Members.Text = Group_Members.Text + $"{GlobalVariables.returnName(username)} ({username})" + Environment.NewLine;

            Add_User_Name.Text = "";
            DisplayUsernamesData.TOTAL_USERNAMES++;
            DisplayUsernamesData.NAMES_IN.Add(username);
        }

        private void resetData()
        {
            DisplayUsernamesData.TOTAL_USERNAMES = 0;
            DisplayUsernamesData.NAMES_IN = new List<string>();
        }

        private void Add_User_Confirm_Click(object sender, RoutedEventArgs e)
        {
            // username is email
            string username = Add_User_Name.Text;

            if (GlobalVariables.isEmailInPeople(username))
            {
                if (!DisplayUsernamesData.NAMES_IN.Contains(username))
                {
                    Group_Members.Text = Group_Members.Text + $"{GlobalVariables.returnName(username)} ({username})" + Environment.NewLine;

                    Add_User_Name.Text = "";
                    DisplayUsernamesData.TOTAL_USERNAMES++;
                    DisplayUsernamesData.NAMES_IN.Add(username);
                }
                else
                {
                    MessageBox.Show("User is already added to group");
                }
            }
            else
            {
                MessageBox.Show("User is not in database!");
            }
        }

        private void Confirm_CreateGroup_Click(object sender, RoutedEventArgs e)
        {
            // Add a colour wheel or something
            Colour_Picker();
            if (Group_Name.Text == "")
            {
                MessageBox.Show("A group name is required");
            }
            else if (Group_Description.Text == "")
            {
                MessageBox.Show("A description is required");
            }
            else {
                MessageBox.Show($"{DisplayUsernamesData.Colour1} {DisplayUsernamesData.Colour2}");
                GlobalVariables.insertIntoGroup(Group_Name.Text, DisplayUsernamesData.Colour1,DisplayUsernamesData.Colour2, Group_Description.Text);

                int groupID = GlobalVariables.returnAmountOfGroups();

                foreach (string email in DisplayUsernamesData.NAMES_IN)
                {
                    GlobalVariables.insertPersonIntoGroup(GlobalVariables.emailToID(email), groupID);
                }

                NavigationService navService = NavigationService.GetNavigationService(this);
                Groups_Page nextPage = new Groups_Page();
                navService.Navigate(nextPage);
            }
        }
        public void Colour_Picker()
        {
            MessageBox.Show("DONE!");
            string text = ColourComboBox.Text;
            DisplayUsernamesData.Colour1 = "White";
            DisplayUsernamesData.Colour2 = "White";

            if(text == "Science")
            {
                DisplayUsernamesData.Colour1 = "#1C75BC";
                DisplayUsernamesData.Colour2 = "#39B1DE";
            }
            else if(text == "English")
            {
                DisplayUsernamesData.Colour1 = "#00808F";
                DisplayUsernamesData.Colour2 = "#48B149";
            }
            else if (text == "Physical Education")
            {
                DisplayUsernamesData.Colour1 = "#00305E";
                DisplayUsernamesData.Colour2 = "#FFD540";
            }
            else if (text == "Technologies")
            {
                DisplayUsernamesData.Colour1 = "#009444";
                DisplayUsernamesData.Colour2 = "#49B749";
            }
            else if (text == "Humanities")
            {
                DisplayUsernamesData.Colour1 = "#EC008C";
                DisplayUsernamesData.Colour2 = "#FFD540";
            }
            else if(text == "Art")
            {
                DisplayUsernamesData.Colour1 = "#ED1C24";
                DisplayUsernamesData.Colour2 = "#F07722";
            }
            else if (text == "Math")
            {
                DisplayUsernamesData.Colour1 = "#EC008C";
                DisplayUsernamesData.Colour2 = " #F287B7";
            }
            else if (text == "Languages")
            {
                DisplayUsernamesData.Colour1 = "#A9B138";
                DisplayUsernamesData.Colour2 = "#C0BC31";
            }


        }
    }

}
